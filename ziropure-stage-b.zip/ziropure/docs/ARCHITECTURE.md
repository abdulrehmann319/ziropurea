# Ziropure — Architecture

Single store, multi-brand. One catalogue, one cart, one checkout. Admin controls everything.

## Layers
- **UI**: Next.js App Router (RSC by default, client components only for interaction), Tailwind v4 tokens in `globals.css`, Motion for animation (all gated by `useReducedMotion`).
- **Auth**: `@supabase/ssr` cookies. `middleware.ts` refreshes sessions; authorization always via `auth.getUser()` in `lib/auth.ts`. Admin = `profiles.role = 'admin'`, rechecked server-side and enforced by RLS.
- **Data**: Supabase Postgres, SQL migrations in `supabase/migrations`, RLS on every table. Prices are integer PKR.
- **Trusted writes**: Server Actions / route handlers only. Order creation recomputes prices, discounts, delivery and stock from the DB; client sends only `{product_id, qty}`. Service-role client (`lib/supabase/admin.ts`) is server-only.
- **Payments**: provider adapter interface; webhook verifies signature, upserts payment by `(provider, provider_ref)` for idempotency, appends to status history.

## Routes
`/` `/shop` `/shop/[slug]` `/brands` `/cart` `/checkout` `/order/[id]` `/login` `/register` `/account/*` `/admin/*` `/api/payments/webhook` + legal/info pages.

## Brand
Logo: charcoal geometric "Z". Used on cream/sage backgrounds with the green palette (the supplied lavender background is not used in the UI).

## Sequence
A Architecture + design system (this commit) → B Storefront → C DB + auth → D Cart + checkout → E Payments → F Admin → G Tests + deploy.
