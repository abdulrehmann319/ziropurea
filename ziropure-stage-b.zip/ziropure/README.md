# Ziropure — storefront (demo build)

Animated herbal-skincare storefront built with Next.js (App Router), TypeScript, Tailwind v4, and Motion.
It runs **entirely on sample data** and is structured so a Supabase backend can be plugged in later without rebuilding the UI.

## Run it
```bash
npm install
cp .env.example .env.local      # defaults to demo mode; no keys needed
npm run dev                     # http://localhost:3000
npm run typecheck && npm run lint
```
> This code was written without being able to run `npm install` / `tsc`, so run the checks above first and fix anything they flag.

## Stage B status (storefront)

**Complete (UI + logic, running on sample data)**
- Homepage: scrolling hero with word-by-word headline reveal, self-drawing botanical sprig, parallax panel, floating leaves, ingredient marquee, category tiles, featured products, daily-ritual section, brands. All motion respects `prefers-reduced-motion`.
- Shop: search, sort, category and brand chips with active state, active-filter summary, empty state, loading skeleton; product detail pages with metadata.
- Cart (persisted in the browser), responsive header with animated mobile menu, Escape-to-close, active-link state, cart badge.
- Pages with forms: login, register, forgot-password, checkout, account (preview), admin (overview, products & inventory, orders). Validation runs server-side with zod.
- `robots.txt`, `sitemap.xml`, per-page metadata, security headers.

**Interfaces only — NOT working until the backend exists (all clearly labelled in the UI)**
- Google sign-in (button disabled), email/password sign-in, registration, email verification, password reset emails
- Placing orders, order confirmation, order history, saved addresses
- Online payments and bank-transfer instructions
- Admin create/edit/delete, image upload, inventory changes, order status updates (admin is also unprotected in demo mode)

**Verification performed**
- `tsc` over all of `src/` using stand-in type declarations for Next/React/Motion/Supabase/zod (those packages could not be installed in the build sandbox), plus a numeric test of `priceCart`.
- **Not performed:** `npm install`, `next build`, `next lint`, browser testing. Run `npm install && npm run typecheck && npm run lint && npm run build` and send any errors.

## What is real vs demo

| Area | Status in demo mode |
|---|---|
| Homepage, animations, navigation, SEO metadata, info pages | **Real** (info-page text is placeholder copy — replace it) |
| Catalogue, search, filters, product pages | **Real UI on SAMPLE data** (`src/data/sample.ts`) |
| Cart (add/remove/quantity, persists in `localStorage`), pricing, delivery fee, sample discount `WELCOME10` | **Real logic** (`src/domain/pricing.ts`) on sample data |
| Form validation (login, register, checkout) | **Real** (zod, server-side in server actions) |
| Login / register / Google sign-in / logout | **Not functional** — returns "not connected". Google button is disabled. |
| Placing orders, order history, saved addresses | **Not functional** — checkout validates and re-prices on the server, then reports "order not placed" |
| Online/card payments, webhooks | **Not functional** — option disabled |
| Admin dashboard | **UI preview only**, sample data, read-only, **unprotected in demo mode** |

Nothing in demo mode creates users, orders or payments. A yellow/beige notice marks every demo area.

## Architecture
```
src/
  app/            Routes, server actions (app/actions), auth callback
  components/     UI (client components only where interactive)
  domain/         Pure business logic: pricing.ts, validation.ts (no I/O, shared client+server)
  config/         env.ts (demo/supabase switch), commerce.ts (fees, limits)
  data/sample.ts  SAMPLE products/orders — delete when real data exists
  server/
    contracts.ts  Interfaces: CatalogRepository, AuthService, OrderService, PaymentGateway
    demo/         Demo implementations (sample data / "not connected")
    supabase/     Supabase implementations (auth done; catalog/orders/payments are TODO stubs)
    index.ts      The ONLY switch between demo and Supabase
  lib/supabase/   Browser, server (cookie) and service-role clients
  middleware.ts   Session refresh + route guarding (active only in supabase mode)
```
Pages never import Supabase directly: they call `catalog`, `auth`, `orders`, `payments` from `@/server`.

## Connecting Supabase later
1. Create a Supabase project; copy URL, anon key, service-role key into `.env.local` (service-role key stays server-only).
2. Create your schema (profiles with `role`, brands, categories, products, product_images, inventory, addresses, orders, order_items, payments, order_status_history) with **Row Level Security on every table**. Only admins may write catalog/orders; customers may read only their own orders/addresses.
3. Implement `src/server/supabase/catalog.ts` (map rows to `src/lib/types.ts`).
4. Implement `src/server/supabase/orders.ts` `create()` as a single transactional Postgres function: re-read prices and stock, decrement inventory, store order items as price snapshots, write status history, accept an idempotency key. Add `getById` with ownership checks and build `/order/[id]`, `/account` order history and addresses on it.
5. Admin writes: add server actions that call `requireAdmin()` first (product CRUD, image upload to Storage, inventory, order status) and enable the disabled controls.
6. Set `NEXT_PUBLIC_BACKEND_MODE=supabase`. Auth (`src/server/supabase/auth.ts`) and the middleware then switch on.

### Google sign-in
1. Google Cloud Console → APIs & Services → OAuth consent screen → configure; then Credentials → Create OAuth client ID (Web).
2. Authorized redirect URI: `https://<project-ref>.supabase.co/auth/v1/callback`.
3. Supabase Dashboard → Authentication → Providers → Google: paste Client ID and Secret.
4. Authentication → URL Configuration: Site URL = your domain; add `http://localhost:3000/auth/callback` and `https://your-domain/auth/callback` to Redirect URLs.
5. Enable email confirmations (Authentication → Providers → Email) for registration verification.

### Payments
Implement `PaymentGateway` in `src/server/supabase/payments.ts` for your chosen Pakistani gateway, then add `src/app/api/payments/webhook/route.ts` that calls `payments.handleWebhook(req)`. Verify the provider signature server-side, upsert payments by `(provider, provider_ref)` so repeated callbacks are harmless, and only mark an order paid from that verified path. Keep merchant secrets in server-only env vars.

## Deploy (Vercel)
Import the repo, add the env vars from `.env.example` (never expose the service-role key or payment secrets with `NEXT_PUBLIC_`), set `NEXT_PUBLIC_SITE_URL` to the production domain, deploy.

## Replacing placeholders
Sample product art (`ProductImage`) → real `next/image` photos; info-page copy in `src/content/info.ts`; contact details; delivery fee and thresholds in `src/config/commerce.ts`.

## Manual test checklist (demo)
- [ ] Home animates; with OS "reduce motion" on, movement stops
- [ ] Mobile menu opens/closes; keyboard Tab shows focus rings; skip link works
- [ ] Shop: search "serum", filter by brand/category, sort by price, clear filters, empty state
- [ ] Product page: add to cart; sold-out product (Ceramide) is disabled
- [ ] Cart: change quantity, remove, code `WELCOME10`, invalid code message, refresh keeps cart
- [ ] Checkout: empty form shows field errors; valid form shows "order not placed" notice and a server-calculated total
- [ ] Login/Register/Forgot password: validation errors; valid submit shows "not connected"; Google disabled
- [ ] Account page shows demo notice and sample order rows; mobile menu opens, closes on Escape and on navigation
- [ ] `/admin` shows sample data with demo banner; all write controls disabled
