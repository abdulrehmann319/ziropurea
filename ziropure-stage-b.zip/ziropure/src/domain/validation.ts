import { z } from "zod";

const password = z.string().min(8, "Use at least 8 characters");
export const loginSchema = z.object({ email: z.string().email("Enter a valid email"), password });
export const registerSchema = z
  .object({
    fullName: z.string().trim().min(2, "Enter your full name"),
    email: z.string().email("Enter a valid email"),
    password,
    confirmPassword: z.string(),
  })
  .refine((d) => d.password === d.confirmPassword, { path: ["confirmPassword"], message: "Passwords do not match" });

export const forgotPasswordSchema = z.object({ email: z.string().email("Enter a valid email") });

export const checkoutSchema = z.object({
  fullName: z.string().trim().min(2, "Enter your full name"),
  email: z.string().email("Enter a valid email"),
  phone: z
    .string()
    .transform((v) => v.replace(/[\s-]/g, ""))
    .pipe(z.string().regex(/^(\+92|0)3\d{9}$/, "Use a Pakistani mobile number, e.g. 03XX XXXXXXX")),
  address: z.string().trim().min(8, "Enter your full delivery address"),
  city: z.string().trim().min(2, "Enter your city"),
  postalCode: z.string().trim().optional(),
  paymentMethod: z.enum(["cod", "bank_transfer", "online"], { message: "Choose a payment method" }),
});
export type CheckoutInput = z.infer<typeof checkoutSchema>;

export const cartLinesSchema = z
  .array(z.object({ productId: z.string(), quantity: z.number().int().min(1).max(50) }))
  .max(50);
