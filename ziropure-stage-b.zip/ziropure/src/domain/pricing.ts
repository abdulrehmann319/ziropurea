import { DELIVERY_FEE, DISCOUNT_CODES, FREE_DELIVERY_OVER, MAX_QTY_PER_LINE } from "@/config/commerce";
import type { Product } from "@/lib/types";

export interface CartLine { productId: string; quantity: number }
export type LineIssue = "NOT_FOUND" | "OUT_OF_STOCK" | "LIMITED_STOCK";
export interface PricedLine { productId: string; name: string; unitPrice: number; quantity: number; lineTotal: number; issue?: LineIssue }
export interface PricedCart {
  lines: PricedLine[]; subtotal: number; discount: number; discountLabel?: string;
  deliveryFee: number; total: number; hasIssues: boolean;
}

/**
 * Pure pricing function. Runs in the browser for previews AND on the server for the
 * authoritative total. The server must always call it with products loaded from the DB.
 */
export function priceCart(lines: CartLine[], products: Product[], discountCode?: string): PricedCart {
  const byId = new Map(products.map((p) => [p.id, p]));
  const priced: PricedLine[] = lines.map((l) => {
    const p = byId.get(l.productId);
    let quantity = Math.max(1, Math.min(MAX_QTY_PER_LINE, Math.floor(l.quantity) || 1));
    if (!p) return { productId: l.productId, name: "Unavailable item", unitPrice: 0, quantity, lineTotal: 0, issue: "NOT_FOUND" as const };
    if (p.stock <= 0) return { productId: p.id, name: p.name, unitPrice: p.price, quantity, lineTotal: 0, issue: "OUT_OF_STOCK" as const };
    let issue: LineIssue | undefined;
    if (quantity > p.stock) { quantity = p.stock; issue = "LIMITED_STOCK"; }
    return { productId: p.id, name: p.name, unitPrice: p.price, quantity, lineTotal: p.price * quantity, issue };
  });
  const subtotal = priced.reduce((s, l) => s + l.lineTotal, 0);
  const code = discountCode?.trim().toUpperCase();
  const rule = code ? DISCOUNT_CODES[code] : undefined;
  const discount = rule ? Math.round((subtotal * rule.percent) / 100) : 0;
  const afterDiscount = subtotal - discount;
  const deliveryFee = subtotal === 0 || afterDiscount >= FREE_DELIVERY_OVER ? 0 : DELIVERY_FEE;
  return {
    lines: priced, subtotal, discount, discountLabel: rule?.label, deliveryFee,
    total: afterDiscount + deliveryFee, hasIssues: priced.some((l) => l.issue),
  };
}
