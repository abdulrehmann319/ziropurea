import type { Metadata } from "next";
import { CartView } from "@/components/CartView";
import { catalog } from "@/server";

export const metadata: Metadata = { title: "Your cart" };

export default async function CartPage() {
  const products = await catalog.listProducts();
  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="font-display text-4xl text-forest-950">Your cart</h1>
      <CartView products={products} />
    </div>
  );
}
