import type { Metadata } from "next";
import { Notice } from "@/components/ui/Notice";
import { ButtonLink } from "@/components/ui/Button";
import { requireUser } from "@/lib/auth";

export const metadata: Metadata = { title: "Order confirmation", robots: { index: false } };

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  // TODO (backend): load the order via an OrderService method that enforces ownership (RLS) and render items/status/payment.
  return (
    <div className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="font-display text-4xl text-forest-950">Thank you</h1>
      <p className="mt-2 text-forest-700">Order reference: <code>{id}</code></p>
      <div className="mt-6 text-left"><Notice tone="demo" title="Needs backend">Order details will appear here once OrderService.getById is implemented.</Notice></div>
      <div className="mt-6"><ButtonLink href="/shop">Continue shopping</ButtonLink></div>
    </div>
  );
}
