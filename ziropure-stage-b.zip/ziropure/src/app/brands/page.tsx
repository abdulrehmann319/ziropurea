import type { Metadata } from "next";
import Link from "next/link";
import { catalog } from "@/server";

export const metadata: Metadata = { title: "Brands" };

export default async function Brands() {
  const [brands, products] = await Promise.all([catalog.listBrands(), catalog.listProducts()]);
  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="font-display text-4xl text-forest-950">Brands</h1>
      <p className="mt-2 text-forest-700">Ziropure and authorized brands (sample brands shown in the demo).</p>
      <ul className="mt-8 grid gap-4 md:grid-cols-3">
        {brands.map((b) => (
          <li key={b.id}><Link href={`/shop?brand=${b.slug}`} className="block rounded-3xl border border-beige-200 bg-white p-6 transition hover:shadow-md">
            <h2 className="font-display text-2xl text-forest-950">{b.name}</h2>
            <p className="mt-1 text-sm text-sage-500">{b.isOwn ? "Our own brand" : "Authorized brand"} · {products.filter((p) => p.brandId === b.id).length} products</p>
          </Link></li>
        ))}
      </ul>
    </div>
  );
}
