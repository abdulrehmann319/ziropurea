import type { Metadata } from "next";
import { InfoPage } from "@/components/InfoPage";
import { INFO } from "@/content/info";

export const metadata: Metadata = { title: INFO["skincare-info"].title };
export default function Page() {
  return <InfoPage page="skincare-info" />;
}
