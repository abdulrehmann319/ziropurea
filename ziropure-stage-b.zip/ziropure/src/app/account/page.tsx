import type { Metadata } from "next";
import { logoutAction } from "@/app/actions/auth";
import { Badge } from "@/components/admin/Badge";
import { ButtonLink, buttonClass } from "@/components/ui/Button";
import { Notice } from "@/components/ui/Notice";
import { isBackendLive } from "@/config/env";
import { requireUser } from "@/lib/auth";
import { formatPKR } from "@/lib/format";
import { orders } from "@/server";

export const metadata: Metadata = { title: "My account", robots: { index: false } };

export default async function Account() {
  const user = isBackendLive ? await requireUser() : null;
  const myOrders = await orders.listMine(user?.id ?? "demo-preview");
  const card = "rounded-2xl border border-beige-200 bg-white p-5";

  return (
    <div className="mx-auto max-w-4xl px-4 py-12">
      <h1 className="font-display text-4xl text-forest-950">My account</h1>
      {!isBackendLive && (
        <div className="mt-4"><Notice tone="demo" title="Demo preview">You are not signed in — this page shows how the account area will look. Profile, addresses and order history need backend integration; the orders below are <strong>sample rows</strong>.</Notice></div>
      )}

      <div className="mt-8 grid gap-6 md:grid-cols-2">
        <section className={card} aria-labelledby="profile-h">
          <h2 id="profile-h" className="font-display text-xl text-forest-950">Profile</h2>
          <p className="mt-2 text-sm text-forest-700">{user ? user.email : "demo@example.com (placeholder)"}</p>
          <button disabled className={`${buttonClass("outline")} mt-4`}>Edit profile</button>
        </section>
        <section className={card} aria-labelledby="addr-h">
          <h2 id="addr-h" className="font-display text-xl text-forest-950">Saved addresses</h2>
          <p className="mt-2 text-sm text-forest-700">No saved addresses yet.</p>
          <button disabled className={`${buttonClass("outline")} mt-4`}>Add address</button>
        </section>
      </div>

      <section className="mt-8" aria-labelledby="orders-h">
        <h2 id="orders-h" className="font-display text-2xl text-forest-950">Order history</h2>
        {myOrders.length === 0 ? (
          <div className="mt-3 rounded-2xl bg-sage-100 p-8 text-center"><p className="font-display text-lg text-forest-950">No orders yet</p><div className="mt-4"><ButtonLink href="/shop">Start shopping</ButtonLink></div></div>
        ) : (
          <ul className="mt-3 divide-y divide-beige-200 rounded-2xl border border-beige-200 bg-white">
            {myOrders.map((o) => (
              <li key={o.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                <span>{o.id}<span className="ml-2 text-xs text-sage-500">{new Date(o.createdAt).toLocaleDateString("en-PK")}</span></span>
                <span className="flex items-center gap-2"><Badge value={o.status} />{formatPKR(o.total)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {user && <form action={logoutAction} className="mt-8"><button className={buttonClass("outline")}>Sign out</button></form>}
    </div>
  );
}
