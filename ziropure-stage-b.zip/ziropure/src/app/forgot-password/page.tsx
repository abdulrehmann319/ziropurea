import type { Metadata } from "next";
import { AuthForms } from "../login/shell";

export const metadata: Metadata = { title: "Forgot password", robots: { index: false } };
export default function Page() {
  return <AuthForms mode="forgot" />;
}
