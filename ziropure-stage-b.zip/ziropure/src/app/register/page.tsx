import type { Metadata } from "next";
import { AuthForms } from "../login/shell";
export const metadata: Metadata = { title: "Create account" };
export default function Page() { return <AuthForms mode="register" />; }
