"use server";
import { redirect } from "next/navigation";
import type { ActionState } from "@/lib/action-state";
import { forgotPasswordSchema, loginSchema, registerSchema } from "@/domain/validation";
import { auth } from "@/server";

export async function loginAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = loginSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { ok: false, message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  const res = await auth.signInWithPassword(parsed.data);
  if (!res.ok) return { ok: false, code: res.code, message: res.message };
  const next = String(fd.get("next") ?? "/account");
  redirect(next.startsWith("/") && !next.startsWith("//") ? next : "/account");
}

export async function registerAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = registerSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { ok: false, message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  const res = await auth.signUp({ email: parsed.data.email, password: parsed.data.password, fullName: parsed.data.fullName });
  if (!res.ok) return { ok: false, code: res.code, message: res.message };
  return { ok: true, message: "Check your email to verify your account, then sign in." };
}

export async function forgotPasswordAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = forgotPasswordSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { ok: false, message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };
  const res = await auth.requestPasswordReset(parsed.data.email);
  if (!res.ok && res.code === "BACKEND_NOT_CONFIGURED") return { ok: false, code: res.code, message: res.message };
  // Same answer whether or not the account exists (prevents email enumeration).
  return { ok: true, message: "If an account exists for that email, a reset link is on its way." };
}

export async function googleAction(): Promise<void> {
  const res = await auth.signInWithGoogle();
  if (res.ok) redirect(res.data.url);
  redirect("/login?error=google");
}

export async function logoutAction(): Promise<void> {
  await auth.signOut();
  redirect("/");
}
