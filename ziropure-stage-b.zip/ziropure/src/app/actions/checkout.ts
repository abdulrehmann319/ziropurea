"use server";
import { redirect } from "next/navigation";
import type { ActionState } from "@/lib/action-state";
import { priceCart, type CartLine } from "@/domain/pricing";
import { cartLinesSchema, checkoutSchema } from "@/domain/validation";
import { catalog, orders } from "@/server";

/** Validates the form, re-prices the cart from catalog data on the server, then asks the order service to create the order. */
export async function checkoutAction(_prev: ActionState, fd: FormData): Promise<ActionState> {
  const parsed = checkoutSchema.safeParse(Object.fromEntries(fd));
  if (!parsed.success) return { ok: false, message: "Please fix the highlighted fields.", fieldErrors: parsed.error.flatten().fieldErrors };

  let lines: CartLine[];
  try {
    lines = cartLinesSchema.parse(JSON.parse(String(fd.get("cart") ?? "[]")));
  } catch {
    return { ok: false, message: "Your cart could not be read. Please refresh and try again." };
  }
  if (lines.length === 0) return { ok: false, message: "Your cart is empty." };

  const products = await catalog.getByIds(lines.map((l) => l.productId));
  const priced = priceCart(lines, products, String(fd.get("discountCode") ?? "") || undefined);
  if (priced.hasIssues) return { ok: false, message: "Some items are unavailable or low in stock. Please review your cart." };

  const res = await orders.create({ customer: parsed.data, priced });
  if (!res.ok) return { ok: false, code: res.code, message: res.message, serverTotal: priced.total };
  redirect(`/order/${res.data.orderId}`);
}
