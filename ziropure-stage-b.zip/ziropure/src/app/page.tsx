import Link from "next/link";
import { Hero } from "@/components/Hero";
import { Marquee } from "@/components/Marquee";
import { ProductCard } from "@/components/ProductCard";
import { Reveal } from "@/components/Reveal";
import { ButtonLink } from "@/components/ui/Button";
import { catalog } from "@/server";

const ritual = [
  { step: "01", title: "Cleanse", text: "Remove the day gently with a herbal cleanser.", href: "/shop?category=cleansers" },
  { step: "02", title: "Treat", text: "Target your concerns with a serum or mask.", href: "/shop?category=serums" },
  { step: "03", title: "Protect", text: "Moisturise, then finish with daily sunscreen.", href: "/shop?category=sun-care" },
];
const values = [
  { title: "Herbal first", text: "Formulas built around botanicals like neem, aloe, rose and saffron." },
  { title: "One trusted shop", text: "Ziropure plus carefully selected authorized brands, in a single cart." },
  { title: "Delivered in Pakistan", text: "Cash on delivery and bank transfer, with clear delivery fees." },
];
const ingredients = ["Neem", "Aloe vera", "Rose water", "Saffron", "Sandalwood", "Tulsi", "Turmeric", "Green tea"];

export default async function Home() {
  const [products, brands, categories] = await Promise.all([catalog.listProducts(), catalog.listBrands(), catalog.listCategories()]);
  const brandName = (id: string) => brands.find((b) => b.id === id)?.name ?? "";
  return (
    <>
      <Hero />
      <Marquee items={ingredients} />

      <section className="mx-auto max-w-6xl px-4 py-16">
        <Reveal><h2 className="font-display text-3xl text-forest-900">Shop by category</h2></Reveal>
        <ul className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-5">
          {categories.map((c, i) => (
            <li key={c.id}>
              <Reveal delay={i * 0.06}>
                <Link href={`/shop?category=${c.slug}`} className="group block rounded-2xl bg-sage-100 p-5 transition hover:-translate-y-1 hover:bg-sage-300/60">
                  <span className="font-display text-lg text-forest-950">{c.name}</span>
                  <span className="mt-6 block text-sm text-forest-700 transition group-hover:translate-x-1">Explore →</span>
                </Link>
              </Reveal>
            </li>
          ))}
        </ul>
      </section>

      <section className="mx-auto max-w-6xl px-4">
        <Reveal>
          <div className="flex items-end justify-between gap-4">
            <div><h2 className="font-display text-3xl text-forest-900">Featured products</h2><p className="mt-1 text-sm text-sage-500">Sample products for the demo preview.</p></div>
            <Link href="/shop" className="text-sm text-forest-900 underline">View all</Link>
          </div>
        </Reveal>
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
          {products.slice(0, 4).map((p, i) => (<Reveal key={p.id} delay={i * 0.07}><ProductCard product={p} brandName={brandName(p.brandId)} /></Reveal>))}
        </div>
      </section>

      <section className="mt-20 bg-forest-950 py-16 text-cream-100">
        <div className="mx-auto max-w-6xl px-4">
          <Reveal><h2 className="font-display text-3xl">A simple daily ritual</h2></Reveal>
          <ol className="mt-8 grid gap-6 md:grid-cols-3">
            {ritual.map((r, i) => (
              <li key={r.step}>
                <Reveal delay={i * 0.12}>
                  <Link href={r.href} className="block rounded-3xl border border-forest-700 p-6 transition hover:bg-forest-900">
                    <span className="font-display text-4xl text-sage-300">{r.step}</span>
                    <h3 className="mt-3 font-display text-xl">{r.title}</h3>
                    <p className="mt-1 text-sm text-sage-300">{r.text}</p>
                  </Link>
                </Reveal>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-16 md:grid-cols-3">
        {values.map((v, i) => (
          <Reveal key={v.title} delay={i * 0.1}>
            <div className="h-full rounded-3xl bg-sage-100 p-6"><h3 className="font-display text-xl text-forest-950">{v.title}</h3><p className="mt-2 text-sm text-forest-700">{v.text}</p></div>
          </Reveal>
        ))}
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-4">
        <Reveal>
          <h2 className="font-display text-3xl text-forest-900">Our brands</h2>
          <ul className="mt-5 flex flex-wrap gap-3">
            {brands.map((b) => <li key={b.id}><Link href={`/shop?brand=${b.slug}`} className="inline-block rounded-full border border-forest-900/30 px-5 py-2 text-sm text-forest-900 hover:bg-sage-100">{b.name}{!b.isOwn && " (sample)"}</Link></li>)}
          </ul>
          <div className="mt-8"><ButtonLink href="/brands" variant="outline">All brands</ButtonLink></div>
        </Reveal>
      </section>
    </>
  );
}
