import { ButtonLink } from "@/components/ui/Button";

export default function NotFound() {
  return (
    <div className="mx-auto max-w-lg px-4 py-24 text-center">
      <h1 className="font-display text-4xl text-forest-950">Page not found</h1>
      <p className="mt-3 text-forest-700">The page you are looking for does not exist or has moved.</p>
      <div className="mt-6"><ButtonLink href="/shop">Browse products</ButtonLink></div>
    </div>
  );
}
