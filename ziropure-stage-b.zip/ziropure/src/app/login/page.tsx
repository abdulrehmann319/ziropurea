import type { Metadata } from "next";
import { AuthForms } from "./shell";
export const metadata: Metadata = { title: "Sign in" };
export default async function Page({ searchParams }: { searchParams: Promise<{ next?: string; error?: string }> }) {
  const sp = await searchParams;
  return <AuthForms mode="login" next={sp.next} error={sp.error} />;
}
