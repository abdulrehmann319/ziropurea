import { ForgotForm, LoginForm, RegisterForm } from "@/components/AuthForms";
import { GoogleButton } from "@/components/GoogleButton";
import { Notice } from "@/components/ui/Notice";
import { isBackendLive } from "@/config/env";

const titles = { login: "Welcome back", register: "Create your account", forgot: "Reset your password" } as const;

export function AuthForms({ mode, next, error }: { mode: keyof typeof titles; next?: string; error?: string }) {
  return (
    <div className="mx-auto max-w-md px-4 py-14">
      <h1 className="font-display text-4xl text-forest-950">{titles[mode]}</h1>
      {mode === "forgot" && <p className="mt-2 text-forest-700">Enter your email and we will send you a link to choose a new password.</p>}
      <div className="mt-6 space-y-4">
        {!isBackendLive && (
          <Notice tone="demo" title="Demo — authentication not connected">
            Forms validate, but no account is created, no email is sent and no one can sign in until Supabase is connected.
          </Notice>
        )}
        {error && <Notice tone="error">Sign-in could not be completed. Please try again.</Notice>}
        {mode !== "forgot" && <GoogleButton />}
        {mode === "login" && <LoginForm next={next} />}
        {mode === "register" && <RegisterForm />}
        {mode === "forgot" && <ForgotForm />}
      </div>
    </div>
  );
}
