import { NextResponse } from "next/server";
import { isBackendLive } from "@/config/env";
import { createClient } from "@/lib/supabase/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const rawNext = searchParams.get("next") ?? "/account";
  const next = rawNext.startsWith("/") && !rawNext.startsWith("//") ? rawNext : "/account";
  if (!isBackendLive || !code) return NextResponse.redirect(`${origin}/login?error=callback`);
  const supabase = await createClient();
  const { error } = await supabase.auth.exchangeCodeForSession(code);
  return NextResponse.redirect(`${origin}${error ? "/login?error=callback" : next}`);
}
