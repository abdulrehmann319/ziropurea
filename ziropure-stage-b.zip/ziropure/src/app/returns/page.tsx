import type { Metadata } from "next";
import { InfoPage } from "@/components/InfoPage";
import { INFO } from "@/content/info";

export const metadata: Metadata = { title: INFO["returns"].title };
export default function Page() {
  return <InfoPage page="returns" />;
}
