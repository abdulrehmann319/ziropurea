import type { Metadata } from "next";
import Link from "next/link";
import { ProductCard } from "@/components/ProductCard";
import { buttonClass } from "@/components/ui/Button";
import { catalog } from "@/server";
import type { ProductFilters } from "@/server/contracts";

export const metadata: Metadata = { title: "Shop", description: "Herbal skincare and authorized brands." };
type SP = { q?: string; category?: string; brand?: string; sort?: string };
const control = "mt-1 w-full rounded-lg border border-beige-400 bg-white px-3 py-2.5 text-sm";

function Chip({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link href={href} aria-current={active ? "true" : undefined} className={`rounded-full border px-4 py-1.5 text-sm transition ${active ? "border-forest-900 bg-forest-900 text-cream-50" : "border-forest-900/30 text-forest-900 hover:bg-sage-100"}`}>{children}</Link>
  );
}

export default async function Shop({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const sort = (["price-asc", "price-desc"].includes(sp.sort ?? "") ? sp.sort : "featured") as ProductFilters["sort"];
  const [products, brands, categories] = await Promise.all([
    catalog.listProducts({ q: sp.q, category: sp.category, brand: sp.brand, sort }),
    catalog.listBrands(),
    catalog.listCategories(),
  ]);
  const brandName = (id: string) => brands.find((b) => b.id === id)?.name ?? "";
  const href = (o: Partial<Record<keyof SP, string | undefined>>) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries({ q: sp.q, category: sp.category, brand: sp.brand, sort: sp.sort, ...o })) if (v) params.set(k, v);
    const s = params.toString();
    return s ? `/shop?${s}` : "/shop";
  };
  const activeCategory = categories.find((c) => c.slug === sp.category);
  const activeBrand = brands.find((b) => b.slug === sp.brand);
  const hasFilters = Boolean(sp.q || activeCategory || activeBrand);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="font-display text-4xl text-forest-950">Shop</h1>

      <form method="get" className="mt-6 grid gap-3 md:grid-cols-[1fr_220px_auto] md:items-end">
        {sp.category && <input type="hidden" name="category" value={sp.category} />}
        {sp.brand && <input type="hidden" name="brand" value={sp.brand} />}
        <div><label htmlFor="q" className="text-sm font-medium text-forest-900">Search</label><input id="q" name="q" type="search" defaultValue={sp.q} placeholder="e.g. serum, neem, spf" className={control} /></div>
        <div><label htmlFor="sort" className="text-sm font-medium text-forest-900">Sort by</label>
          <select id="sort" name="sort" defaultValue={sort} className={control}><option value="featured">Featured</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option></select></div>
        <button className={buttonClass()}>Apply</button>
      </form>

      <div className="mt-6 space-y-3">
        <div><p className="mb-2 text-xs uppercase tracking-wider text-sage-500">Category</p>
          <div className="flex flex-wrap gap-2"><Chip href={href({ category: undefined })} active={!sp.category}>All</Chip>{categories.map((c) => <Chip key={c.id} href={href({ category: c.slug })} active={sp.category === c.slug}>{c.name}</Chip>)}</div></div>
        <div><p className="mb-2 text-xs uppercase tracking-wider text-sage-500">Brand</p>
          <div className="flex flex-wrap gap-2"><Chip href={href({ brand: undefined })} active={!sp.brand}>All</Chip>{brands.map((b) => <Chip key={b.id} href={href({ brand: b.slug })} active={sp.brand === b.slug}>{b.name}</Chip>)}</div></div>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-sage-500" aria-live="polite">
        <span>{products.length} product{products.length === 1 ? "" : "s"} (sample data)</span>
        {hasFilters && <Link href="/shop" className="text-forest-900 underline">Clear all filters</Link>}
        {sp.q && <span className="rounded-full bg-beige-200 px-3 py-0.5 text-forest-900">“{sp.q}”</span>}
      </div>

      {products.length === 0 ? (
        <div className="mt-6 rounded-2xl bg-sage-100 p-10 text-center"><p className="font-display text-xl text-forest-950">No products match your filters</p><p className="mt-1 text-sm text-forest-700">Try a different search or clear the filters.</p><div className="mt-4"><Link href="/shop" className={buttonClass("outline")}>Clear filters</Link></div></div>
      ) : (
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">{products.map((p) => <ProductCard key={p.id} product={p} brandName={brandName(p.brandId)} />)}</div>
      )}
    </div>
  );
}
