import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { AddToCartButton } from "@/components/AddToCartButton";
import { ProductImage } from "@/components/ProductImage";
import { Reveal } from "@/components/Reveal";
import { formatPKR } from "@/lib/format";
import { catalog } from "@/server";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const product = await catalog.getBySlug((await params).slug);
  return product ? { title: product.name, description: product.shortDescription } : { title: "Product not found" };
}

export default async function ProductPage({ params }: { params: Params }) {
  const product = await catalog.getBySlug((await params).slug);
  if (!product) notFound();
  const [brands, categories] = await Promise.all([catalog.listBrands(), catalog.listCategories()]);
  const brand = brands.find((b) => b.id === product.brandId);
  const category = categories.find((c) => c.id === product.categoryId);

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <nav aria-label="Breadcrumb" className="text-sm text-sage-500"><Link href="/shop" className="hover:text-forest-900">Shop</Link> / {category?.name}</nav>
      <div className="mt-6 grid gap-10 md:grid-cols-2">
        <Reveal><ProductImage tint={product.tint} name={product.name} /></Reveal>
        <Reveal delay={0.1}>
          <p className="text-xs uppercase tracking-wider text-sage-500">{brand?.name}</p>
          <h1 className="mt-1 font-display text-4xl text-forest-950">{product.name}</h1>
          <p className="mt-4 text-2xl font-semibold text-forest-900">{formatPKR(product.price)}
            {product.compareAtPrice && <span className="ml-3 text-base font-normal text-sage-500 line-through">{formatPKR(product.compareAtPrice)}</span>}</p>
          <p className="mt-4 text-forest-700">{product.description}</p>
          <p className="mt-3 text-sm">{product.stock > 0 ? <span className="text-forest-600">In stock</span> : <span className="text-red-700">Currently sold out</span>}</p>
          <div className="mt-6 max-w-xs"><AddToCartButton productId={product.id} stock={product.stock} full /></div>
          <h2 className="mt-10 font-display text-xl text-forest-950">Key ingredients</h2>
          <ul className="mt-2 list-inside list-disc text-sm text-forest-700">{product.ingredients.map((i) => <li key={i}>{i}</li>)}</ul>
          <p className="mt-6 text-xs text-sage-500">Sample product shown for the demo. Always patch-test new skincare products.</p>
        </Reveal>
      </div>
    </div>
  );
}
