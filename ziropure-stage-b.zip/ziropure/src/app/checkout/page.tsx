import type { Metadata } from "next";
import { CheckoutForm } from "@/components/CheckoutForm";
import { catalog } from "@/server";

export const metadata: Metadata = { title: "Checkout" };

export default async function CheckoutPage() {
  const products = await catalog.listProducts();
  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <h1 className="font-display text-4xl text-forest-950">Checkout</h1>
      <CheckoutForm products={products} />
    </div>
  );
}
