import type { MetadataRoute } from "next";
import { catalog } from "@/server";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const pages = ["", "/shop", "/brands", "/shipping", "/returns", "/privacy", "/terms", "/contact", "/skincare-info"].map((p) => ({ url: `${base}${p}` }));
  try {
    const products = await catalog.listProducts();
    return [...pages, ...products.map((p) => ({ url: `${base}/shop/${p.slug}` }))];
  } catch {
    return pages; // catalog not available yet
  }
}
