import Link from "next/link";
import { Notice } from "@/components/ui/Notice";
import { isBackendLive } from "@/config/env";
import { requireAdmin } from "@/lib/auth";

export const metadata = { title: "Admin", robots: { index: false, follow: false } };

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await requireAdmin();
  const nav = [["/admin", "Overview"], ["/admin/products", "Products & inventory"], ["/admin/orders", "Orders"]];
  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      {!isBackendLive && (
        <div className="mb-6"><Notice tone="demo" title="Admin UI preview (demo)">Read-only sample data. This page is <strong>not protected</strong> in demo mode; in live mode only users with the admin role can open it. Create, edit and status actions need backend integration.</Notice></div>
      )}
      <div className="grid gap-8 md:grid-cols-[200px_1fr]">
        <nav aria-label="Admin" className="flex gap-2 md:flex-col">
          {nav.map(([href, label]) => <Link key={href} href={href} className="rounded-lg px-3 py-2 text-sm text-forest-900 hover:bg-sage-100">{label}</Link>)}
        </nav>
        <div>{children}</div>
      </div>
    </div>
  );
}
