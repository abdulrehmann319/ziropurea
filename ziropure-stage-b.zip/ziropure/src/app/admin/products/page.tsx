import { Badge } from "@/components/admin/Badge";
import { Notice } from "@/components/ui/Notice";
import { formatPKR } from "@/lib/format";
import { catalog } from "@/server";

const input = "mt-1 w-full rounded-lg border border-beige-400 bg-cream-100 px-3 py-2 text-sm disabled:opacity-60";

export default async function AdminProducts() {
  const [products, brands, categories] = await Promise.all([catalog.listProducts(), catalog.listBrands(), catalog.listCategories()]);
  return (
    <div>
      <h1 className="font-display text-3xl text-forest-950">Products & inventory</h1>
      <div className="mt-4 overflow-x-auto rounded-2xl border border-beige-200 bg-white">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="bg-sage-100 text-xs uppercase tracking-wider text-forest-700"><tr><th className="p-3">Product</th><th className="p-3">Brand</th><th className="p-3">Category</th><th className="p-3">Price</th><th className="p-3">Stock</th><th className="p-3"><span className="sr-only">Actions</span></th></tr></thead>
          <tbody className="divide-y divide-beige-200">
            {products.map((p) => (
              <tr key={p.id}>
                <td className="p-3 font-medium text-forest-950">{p.name}</td>
                <td className="p-3">{brands.find((b) => b.id === p.brandId)?.name}</td>
                <td className="p-3">{categories.find((c) => c.id === p.categoryId)?.name}</td>
                <td className="p-3">{formatPKR(p.price)}</td>
                <td className="p-3">{p.stock} <Badge value={p.stock === 0 ? "out" : p.stock <= 10 ? "low" : "ok"} label={p.stock === 0 ? "Out" : p.stock <= 10 ? "Low" : "OK"} /></td>
                <td className="p-3"><button disabled className="text-sage-500 disabled:cursor-not-allowed">Edit</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <h2 className="mt-10 font-display text-xl text-forest-950">Add product</h2>
      <div className="mt-3"><Notice tone="demo" title="Needs backend">This form is a UI placeholder. Saving, image upload (Supabase Storage) and inventory adjustments require backend integration.</Notice></div>
      <fieldset disabled className="mt-4 grid gap-4 md:grid-cols-2">
        <div><label className="text-sm font-medium">Name</label><input className={input} /></div>
        <div><label className="text-sm font-medium">Price (PKR)</label><input className={input} inputMode="numeric" /></div>
        <div><label className="text-sm font-medium">Brand</label><select className={input}>{brands.map((b) => <option key={b.id}>{b.name}</option>)}</select></div>
        <div><label className="text-sm font-medium">Category</label><select className={input}>{categories.map((c) => <option key={c.id}>{c.name}</option>)}</select></div>
        <div><label className="text-sm font-medium">Stock</label><input className={input} inputMode="numeric" /></div>
        <div><label className="text-sm font-medium">Images</label><input type="file" className={input} /></div>
        <div className="md:col-span-2"><button className="rounded-full bg-forest-900 px-6 py-3 text-sm text-cream-50 opacity-50">Save product</button></div>
      </fieldset>
    </div>
  );
}
