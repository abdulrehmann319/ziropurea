import { Badge } from "@/components/admin/Badge";
import { formatPKR } from "@/lib/format";
import { orders } from "@/server";

const methodLabel = { cod: "Cash on delivery", bank_transfer: "Bank transfer", online: "Online" } as const;

export default async function AdminOrders() {
  const list = await orders.listAll();
  return (
    <div>
      <h1 className="font-display text-3xl text-forest-950">Orders <span className="text-base text-sage-500">(sample data)</span></h1>
      <div className="mt-4 overflow-x-auto rounded-2xl border border-beige-200 bg-white">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="bg-sage-100 text-xs uppercase tracking-wider text-forest-700"><tr><th className="p-3">Order</th><th className="p-3">Customer</th><th className="p-3">Payment</th><th className="p-3">Status</th><th className="p-3">Total</th><th className="p-3">Update</th></tr></thead>
          <tbody className="divide-y divide-beige-200">
            {list.map((o) => (
              <tr key={o.id}>
                <td className="p-3 font-medium text-forest-950">{o.id}<div className="text-xs text-sage-500">{new Date(o.createdAt).toLocaleDateString("en-PK")}</div></td>
                <td className="p-3">{o.customerName}<div className="text-xs text-sage-500">{o.city}</div></td>
                <td className="p-3">{methodLabel[o.paymentMethod]} <Badge value={o.paymentStatus} /></td>
                <td className="p-3"><Badge value={o.status} /></td>
                <td className="p-3">{formatPKR(o.total)}</td>
                <td className="p-3"><select disabled aria-label={`Status for ${o.id}`} className="rounded border border-beige-400 bg-cream-100 px-2 py-1 text-xs disabled:opacity-60"><option>{o.status}</option></select></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-sm text-sage-500">Status changes require backend integration (server action + audit history).</p>
    </div>
  );
}
