import Link from "next/link";
import { Badge } from "@/components/admin/Badge";
import { formatPKR } from "@/lib/format";
import { catalog, orders } from "@/server";

export default async function AdminOverview() {
  const [products, allOrders] = await Promise.all([catalog.listProducts(), orders.listAll()]);
  const revenue = allOrders.filter((o) => o.paymentStatus === "paid").reduce((s, o) => s + o.total, 0);
  const stats = [
    ["Products", String(products.length)],
    ["Low / out of stock", String(products.filter((p) => p.stock <= 10).length)],
    ["Open orders", String(allOrders.filter((o) => ["pending", "confirmed"].includes(o.status)).length)],
    ["Paid revenue", formatPKR(revenue)],
  ];
  return (
    <div>
      <h1 className="font-display text-3xl text-forest-950">Overview <span className="text-base text-sage-500">(sample data)</span></h1>
      <dl className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map(([k, v]) => <div key={k} className="rounded-2xl border border-beige-200 bg-white p-4"><dt className="text-xs uppercase tracking-wider text-sage-500">{k}</dt><dd className="mt-1 font-display text-2xl text-forest-950">{v}</dd></div>)}
      </dl>
      <h2 className="mt-10 font-display text-xl text-forest-950">Recent orders</h2>
      <ul className="mt-3 divide-y divide-beige-200 rounded-2xl border border-beige-200 bg-white">
        {allOrders.slice(0, 4).map((o) => (
          <li key={o.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm"><span>{o.id} · {o.customerName}</span><span className="flex items-center gap-2"><Badge value={o.status} />{formatPKR(o.total)}</span></li>
        ))}
      </ul>
      <p className="mt-3 text-sm"><Link href="/admin/orders" className="underline">View all orders</Link></p>
    </div>
  );
}
