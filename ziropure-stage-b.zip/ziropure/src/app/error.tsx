"use client";
export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="mx-auto max-w-lg px-4 py-24 text-center">
      <h1 className="font-display text-3xl text-forest-950">Something went wrong</h1>
      <p className="mt-3 text-forest-700">Please try again. If the problem continues, contact us.</p>
      <button onClick={reset} className="mt-6 rounded-full bg-forest-900 px-6 py-3 text-sm text-cream-50">Try again</button>
    </div>
  );
}
