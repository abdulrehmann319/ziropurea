export function Marquee({ items }: { items: string[] }) {
  const row = [...items, ...items];
  return (
    <div className="overflow-hidden border-y border-beige-200 bg-cream-100 py-4" aria-hidden>
      <div className="marquee flex w-max gap-12">
        {row.map((t, i) => (
          <span key={i} className="whitespace-nowrap font-display text-xl text-forest-700">{t} <span className="text-sage-500">✦</span></span>
        ))}
      </div>
    </div>
  );
}
