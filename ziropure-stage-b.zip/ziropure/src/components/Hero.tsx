"use client";
import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "motion/react";
import { FloatingLeaves } from "./FloatingLeaves";
import { Sprig } from "./Sprig";
import { ButtonLink } from "./ui/Button";

const headline = "Pure botanicals, thoughtfully chosen for your skin.";

export function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const panelY = useTransform(scrollYProgress, [0, 1], [0, reduce ? 0 : 90]);
  const textFade = useTransform(scrollYProgress, [0, 1], [1, reduce ? 1 : 0.15]);

  return (
    <section ref={ref} className="relative isolate overflow-hidden bg-gradient-to-b from-sage-100 via-cream-50 to-cream-50">
      <FloatingLeaves />
      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 py-14 md:grid-cols-2 md:py-24">
        <motion.div style={{ opacity: textFade }}>
          <motion.p initial={reduce ? false : { opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8 }} className="text-sm uppercase tracking-[0.25em] text-forest-600">
            Herbal skincare · Pakistan
          </motion.p>
          <h1 aria-label={headline} className="mt-4 font-display text-4xl leading-[1.1] text-forest-950 md:text-6xl">
            {headline.split(" ").map((w, i) => (
              <span key={i} aria-hidden className="inline-block overflow-hidden pb-1 align-bottom">
                <motion.span
                  className="inline-block" initial={reduce ? false : { y: "110%" }} animate={{ y: 0 }}
                  transition={{ duration: 0.7, delay: 0.15 + i * 0.08, ease: [0.22, 1, 0.36, 1] }}
                >{w}&nbsp;</motion.span>
              </span>
            ))}
          </h1>
          <motion.p initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9, duration: 0.7 }} className="mt-5 max-w-md text-forest-700">
            Ziropure and authorized skincare brands in one shop, with cash on delivery across Pakistan.
          </motion.p>
          <motion.div initial={reduce ? false : { opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.05, duration: 0.7 }} className="mt-8 flex flex-wrap gap-3">
            <ButtonLink href="/shop">Shop now</ButtonLink>
            <ButtonLink href="/skincare-info" variant="outline">Skincare guide</ButtonLink>
          </motion.div>
        </motion.div>

        <motion.div style={{ y: panelY }} className="relative mx-auto aspect-[4/5] w-full max-w-sm">
          <div className="absolute inset-0 rounded-t-full bg-forest-900" />
          <div className="absolute inset-3 rounded-t-full border border-sage-300/40" />
          <Sprig className="absolute inset-x-0 bottom-6 top-12 mx-auto h-[85%] text-sage-300" />
          <p className="absolute inset-x-0 bottom-3 text-center text-[10px] uppercase tracking-widest text-sage-300">Illustration · sample</p>
        </motion.div>
      </div>
    </section>
  );
}
