"use client";
import { motion, useReducedMotion } from "motion/react";

const leaves = [
  { x: "8%", y: "18%", size: 64, dur: 9, rot: 18 },
  { x: "82%", y: "12%", size: 48, dur: 11, rot: -22 },
  { x: "70%", y: "70%", size: 80, dur: 13, rot: 12 },
  { x: "14%", y: "76%", size: 52, dur: 10, rot: -14 },
];

export function FloatingLeaves() {
  const reduce = useReducedMotion();
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      {leaves.map((l, i) => (
        <motion.svg
          key={i}
          viewBox="0 0 64 64"
          width={l.size}
          height={l.size}
          className="absolute text-sage-300/60"
          style={{ left: l.x, top: l.y }}
          animate={reduce ? undefined : { y: [0, -18, 0], rotate: [l.rot, l.rot + 8, l.rot] }}
          transition={{ duration: l.dur, repeat: Infinity, ease: "easeInOut" }}
        >
          <path fill="currentColor" d="M32 4C14 16 10 36 32 60c22-24 18-44 0-56Zm0 10v40" />
          <path stroke="#fbf8f1" strokeWidth="1.5" fill="none" d="M32 14v40" />
        </motion.svg>
      ))}
    </div>
  );
}
