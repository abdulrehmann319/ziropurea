"use client";
import Link from "next/link";
import { OrderSummary } from "@/components/OrderSummary";
import { ProductImage } from "@/components/ProductImage";
import { ButtonLink } from "@/components/ui/Button";
import { DISCOUNT_CODES } from "@/config/commerce";
import { priceCart } from "@/domain/pricing";
import { formatPKR } from "@/lib/format";
import type { Product } from "@/lib/types";
import { useCart } from "./CartProvider";

export function CartView({ products }: { products: Product[] }) {
  const { lines, hydrated, discountCode, setDiscountCode, setQty, remove } = useCart();
  if (!hydrated) return <div className="skeleton mt-8 h-48 rounded-2xl" aria-busy="true" />;
  if (lines.length === 0)
    return (
      <div className="mt-8 rounded-2xl bg-sage-100 p-10 text-center">
        <p className="font-display text-xl text-forest-950">Your cart is empty</p>
        <p className="mb-5 mt-1 text-sm text-forest-700">Add something from the shop to get started.</p>
        <ButtonLink href="/shop">Browse products</ButtonLink>
      </div>
    );

  const priced = priceCart(lines, products, discountCode);
  const codeValid = !discountCode || Boolean(DISCOUNT_CODES[discountCode.trim().toUpperCase()]);
  return (
    <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]">
      <ul className="space-y-4">
        {priced.lines.map((l) => {
          const product = products.find((p) => p.id === l.productId);
          return (
            <li key={l.productId} className="flex gap-4 rounded-2xl border border-beige-200 bg-white p-3">
              <div className="w-24 shrink-0">{product && <ProductImage tint={product.tint} name={product.name} />}</div>
              <div className="flex-1">
                <Link href={product ? `/shop/${product.slug}` : "/shop"} className="font-display text-lg text-forest-950">{l.name}</Link>
                <p className="text-sm text-forest-700">{formatPKR(l.unitPrice)}</p>
                {l.issue === "OUT_OF_STOCK" && <p className="text-sm text-red-700">Sold out — remove to continue.</p>}
                {l.issue === "LIMITED_STOCK" && <p className="text-sm text-amber-700">Only {l.quantity} available; quantity adjusted.</p>}
                {l.issue === "NOT_FOUND" && <p className="text-sm text-red-700">This item is no longer available.</p>}
                <div className="mt-2 flex items-center gap-3">
                  <div className="flex items-center rounded-full border border-beige-400">
                    <button aria-label={`Decrease quantity of ${l.name}`} className="px-3 py-1" onClick={() => setQty(l.productId, l.quantity - 1)}>−</button>
                    <span className="min-w-6 text-center text-sm" aria-live="polite">{l.quantity}</span>
                    <button aria-label={`Increase quantity of ${l.name}`} className="px-3 py-1" onClick={() => setQty(l.productId, l.quantity + 1)}>+</button>
                  </div>
                  <button className="text-sm text-sage-500 underline" onClick={() => remove(l.productId)}>Remove</button>
                  <span className="ml-auto font-semibold text-forest-900">{formatPKR(l.lineTotal)}</span>
                </div>
              </div>
            </li>
          );
        })}
      </ul>
      <aside className="space-y-4">
        <div>
          <label htmlFor="discount" className="text-sm font-medium text-forest-900">Discount code</label>
          <input id="discount" value={discountCode} onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDiscountCode(e.target.value)} placeholder="Try WELCOME10 (sample)" className="mt-1 w-full rounded-lg border border-beige-400 bg-white px-3 py-2.5 text-sm" />
          {!codeValid && <p className="mt-1 text-sm text-red-700">This code is not valid.</p>}
        </div>
        <OrderSummary priced={priced} />
        {priced.hasIssues ? <p className="text-sm text-red-700">Resolve the items above to continue.</p> : <ButtonLink href="/checkout">Continue to checkout</ButtonLink>}
      </aside>
    </div>
  );
}
