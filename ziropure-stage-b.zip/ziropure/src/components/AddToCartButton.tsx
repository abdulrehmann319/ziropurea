"use client";
import { useState } from "react";
import { useCart } from "./CartProvider";
import { buttonClass } from "./ui/Button";

export function AddToCartButton({ productId, stock, full = false }: { productId: string; stock: number; full?: boolean }) {
  const { add } = useCart();
  const [added, setAdded] = useState(false);
  const soldOut = stock <= 0;
  return (
    <button
      type="button" disabled={soldOut} className={`${buttonClass()} ${full ? "w-full" : ""}`}
      onClick={() => { add(productId); setAdded(true); setTimeout(() => setAdded(false), 1600); }}
    >
      {soldOut ? "Sold out" : added ? "Added ✓" : "Add to cart"}
      <span aria-live="polite" className="sr-only">{added ? "Item added to cart" : ""}</span>
    </button>
  );
}
