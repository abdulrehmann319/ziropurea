import { isBackendLive } from "@/config/env";

export function DemoBar() {
  if (isBackendLive) return null;
  return (
    <div className="bg-forest-950 px-4 py-2 text-center text-xs text-cream-100">
      <strong>DEMO PREVIEW</strong> — sample products and data. Sign-in, orders and payments are not active until the backend is connected.
    </div>
  );
}
