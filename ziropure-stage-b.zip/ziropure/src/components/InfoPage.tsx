import { Reveal } from "@/components/Reveal";
import { INFO } from "@/content/info";

export function InfoPage({ page }: { page: string }) {
  const c = INFO[page];
  return (
    <article className="mx-auto max-w-3xl px-4 py-12">
      <Reveal><h1 className="font-display text-4xl text-forest-950">{c.title}</h1><p className="mt-3 rounded-xl bg-beige-200/60 px-4 py-2 text-sm text-forest-900">{c.intro}</p></Reveal>
      {c.sections.map((s, i) => (
        <Reveal key={s.heading} delay={i * 0.05}><section className="mt-8"><h2 className="font-display text-2xl text-forest-900">{s.heading}</h2><p className="mt-2 text-forest-700">{s.body}</p></section></Reveal>
      ))}
    </article>
  );
}
