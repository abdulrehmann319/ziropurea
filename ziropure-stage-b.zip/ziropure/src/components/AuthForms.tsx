"use client";
import Link from "next/link";
import { useActionState } from "react";
import { forgotPasswordAction, loginAction, registerAction } from "@/app/actions/auth";
import { Field } from "@/components/ui/Field";
import { Notice } from "@/components/ui/Notice";
import { buttonClass } from "@/components/ui/Button";
import type { ActionState } from "@/lib/action-state";

function Status({ state }: { state: ActionState }) {
  if (!state.message) return null;
  if (state.ok) return <Notice tone="success">{state.message}</Notice>;
  return <Notice tone={state.code === "BACKEND_NOT_CONFIGURED" ? "demo" : "error"}>{state.message}</Notice>;
}

export function LoginForm({ next }: { next?: string }) {
  const [state, action, pending] = useActionState<ActionState, FormData>(loginAction, {});
  const fe = state.fieldErrors ?? {};
  return (
    <form action={action} className="space-y-4" noValidate>
      <input type="hidden" name="next" value={next ?? "/account"} />
      <Status state={state} />
      <Field label="Email" name="email" type="email" autoComplete="email" error={fe.email?.[0]} />
      <Field label="Password" name="password" type="password" autoComplete="current-password" error={fe.password?.[0]} />
      <p className="text-right text-sm"><Link href="/forgot-password" className="text-forest-700 underline">Forgot password?</Link></p>
      <button disabled={pending} className={`${buttonClass()} w-full`}>{pending ? "Signing in…" : "Sign in"}</button>
      <p className="text-center text-sm text-forest-700">New here? <Link href="/register" className="underline">Create an account</Link></p>
    </form>
  );
}

export function RegisterForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(registerAction, {});
  const fe = state.fieldErrors ?? {};
  return (
    <form action={action} className="space-y-4" noValidate>
      <Status state={state} />
      <Field label="Full name" name="fullName" autoComplete="name" error={fe.fullName?.[0]} />
      <Field label="Email" name="email" type="email" autoComplete="email" error={fe.email?.[0]} />
      <Field label="Password" name="password" type="password" autoComplete="new-password" error={fe.password?.[0]} />
      <Field label="Confirm password" name="confirmPassword" type="password" autoComplete="new-password" error={fe.confirmPassword?.[0]} />
      <button disabled={pending} className={`${buttonClass()} w-full`}>{pending ? "Creating account…" : "Create account"}</button>
      <p className="text-center text-sm text-forest-700">Already registered? <Link href="/login" className="underline">Sign in</Link></p>
    </form>
  );
}

export function ForgotForm() {
  const [state, action, pending] = useActionState<ActionState, FormData>(forgotPasswordAction, {});
  const fe = state.fieldErrors ?? {};
  return (
    <form action={action} className="space-y-4" noValidate>
      <Status state={state} />
      <Field label="Email" name="email" type="email" autoComplete="email" error={fe.email?.[0]} />
      <button disabled={pending} className={`${buttonClass()} w-full`}>{pending ? "Sending…" : "Send reset link"}</button>
      <p className="text-center text-sm text-forest-700"><Link href="/login" className="underline">Back to sign in</Link></p>
    </form>
  );
}
