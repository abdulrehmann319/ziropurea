/** Placeholder artwork. Replace with next/image of real photography once product_images exist. */
export function ProductImage({ tint, name, className = "" }: { tint: string; name: string; className?: string }) {
  return (
    <div
      role="img" aria-label={`Illustration of ${name} (sample image)`}
      className={`relative aspect-square overflow-hidden rounded-2xl ${className}`}
      style={{ background: `linear-gradient(160deg, ${tint}33, ${tint}99)` }}
    >
      <svg viewBox="0 0 100 100" aria-hidden className="absolute inset-0 h-full w-full">
        <rect x="38" y="32" width="24" height="52" rx="7" fill="#fbf8f1" />
        <rect x="43" y="20" width="14" height="14" rx="3" fill={tint} />
        <path d="M50 48c-8 5-9 12 0 20 9-8 8-15 0-20Z" fill={tint} opacity=".85" />
      </svg>
      <span className="absolute bottom-2 left-2 rounded bg-white/75 px-2 py-0.5 text-[10px] uppercase tracking-wide text-forest-900">Sample image</span>
    </div>
  );
}
