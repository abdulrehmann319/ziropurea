const map: Record<string, string> = {
  pending: "bg-amber-100 text-amber-900", confirmed: "bg-sky-100 text-sky-900", shipped: "bg-indigo-100 text-indigo-900",
  delivered: "bg-sage-100 text-forest-900", cancelled: "bg-red-100 text-red-900",
  unpaid: "bg-amber-100 text-amber-900", paid: "bg-sage-100 text-forest-900", failed: "bg-red-100 text-red-900", refunded: "bg-beige-200 text-forest-900",
  low: "bg-amber-100 text-amber-900", out: "bg-red-100 text-red-900", ok: "bg-sage-100 text-forest-900",
};
export function Badge({ value, label }: { value: string; label?: string }) {
  return <span className={`inline-block rounded-full px-2.5 py-0.5 text-xs font-medium ${map[value] ?? "bg-beige-200"}`}>{label ?? value.replace("_", " ")}</span>;
}
