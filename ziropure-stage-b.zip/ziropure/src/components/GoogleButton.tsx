import { googleAction } from "@/app/actions/auth";
import { isBackendLive } from "@/config/env";

export function GoogleButton() {
  return (
    <div>
      <form action={googleAction}>
        <button disabled={!isBackendLive} className="flex w-full items-center justify-center gap-2 rounded-full border border-forest-900/40 bg-white px-6 py-3 text-sm font-medium text-forest-900 disabled:cursor-not-allowed disabled:opacity-50">
          Continue with Google
        </button>
      </form>
      {!isBackendLive && <p className="mt-2 text-center text-xs text-sage-500">Disabled in demo — requires Supabase + Google OAuth setup.</p>}
      <p className="my-4 text-center text-xs uppercase tracking-wider text-sage-500">or use email</p>
    </div>
  );
}
