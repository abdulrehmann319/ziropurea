import { formatPKR } from "@/lib/format";
import type { PricedCart } from "@/domain/pricing";

export function OrderSummary({ priced }: { priced: PricedCart }) {
  const row = "flex justify-between py-1.5 text-sm";
  return (
    <dl className="rounded-2xl border border-beige-200 bg-white p-5">
      <div className={row}><dt>Subtotal</dt><dd>{formatPKR(priced.subtotal)}</dd></div>
      {priced.discount > 0 && <div className={`${row} text-forest-600`}><dt>Discount ({priced.discountLabel})</dt><dd>−{formatPKR(priced.discount)}</dd></div>}
      <div className={row}><dt>Delivery</dt><dd>{priced.deliveryFee === 0 ? "Free" : formatPKR(priced.deliveryFee)}</dd></div>
      <div className="mt-2 flex justify-between border-t border-beige-200 pt-3 text-base font-semibold text-forest-950"><dt>Total</dt><dd>{formatPKR(priced.total)}</dd></div>
      <p className="mt-3 text-xs text-sage-500">Preview only. The final total is recalculated on the server at checkout.</p>
    </dl>
  );
}
