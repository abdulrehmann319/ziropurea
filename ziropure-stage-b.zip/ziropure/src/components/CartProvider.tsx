"use client";
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { MAX_QTY_PER_LINE } from "@/config/commerce";
import type { CartLine } from "@/domain/pricing";

const KEY = "ziropure-cart-v1";
type Ctx = {
  lines: CartLine[]; discountCode: string; hydrated: boolean; count: number;
  add: (id: string, qty?: number) => void; setQty: (id: string, qty: number) => void;
  remove: (id: string) => void; clear: () => void; setDiscountCode: (c: string) => void;
};
const CartCtx = createContext<Ctx | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [discountCode, setDiscountCode] = useState("");
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (Array.isArray(data.lines)) setLines(data.lines);
        if (typeof data.discountCode === "string") setDiscountCode(data.discountCode);
      }
    } catch { /* ignore corrupt storage */ }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try { localStorage.setItem(KEY, JSON.stringify({ lines, discountCode })); } catch { /* storage unavailable */ }
  }, [lines, discountCode, hydrated]);

  const add = useCallback((id: string, qty = 1) => {
    setLines((prev) => {
      const found = prev.find((l) => l.productId === id);
      if (!found) return [...prev, { productId: id, quantity: Math.min(qty, MAX_QTY_PER_LINE) }];
      return prev.map((l) => (l.productId === id ? { ...l, quantity: Math.min(l.quantity + qty, MAX_QTY_PER_LINE) } : l));
    });
  }, []);
  const setQty = useCallback((id: string, qty: number) => {
    setLines((prev) => prev.map((l) => (l.productId === id ? { ...l, quantity: Math.max(1, Math.min(qty, MAX_QTY_PER_LINE)) } : l)));
  }, []);
  const remove = useCallback((id: string) => setLines((prev) => prev.filter((l) => l.productId !== id)), []);
  const clear = useCallback(() => { setLines([]); setDiscountCode(""); }, []);

  const value = useMemo<Ctx>(
    () => ({ lines, discountCode, hydrated, count: lines.reduce((s, l) => s + l.quantity, 0), add, setQty, remove, clear, setDiscountCode }),
    [lines, discountCode, hydrated, add, setQty, remove, clear],
  );
  return <CartCtx.Provider value={value}>{children}</CartCtx.Provider>;
}

export function useCart() {
  const ctx = useContext(CartCtx);
  if (!ctx) throw new Error("useCart must be used inside <CartProvider>");
  return ctx;
}
