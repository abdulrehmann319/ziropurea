"use client";
import { useActionState } from "react";
import { checkoutAction } from "@/app/actions/checkout";
import { OrderSummary } from "@/components/OrderSummary";
import { Field } from "@/components/ui/Field";
import { Notice } from "@/components/ui/Notice";
import { ButtonLink, buttonClass } from "@/components/ui/Button";
import { isBackendLive } from "@/config/env";
import { priceCart } from "@/domain/pricing";
import { formatPKR } from "@/lib/format";
import type { ActionState } from "@/lib/action-state";
import type { Product } from "@/lib/types";
import { useCart } from "./CartProvider";

const methods = [
  { id: "cod", label: "Cash on delivery", hint: "Pay the courier when your order arrives.", enabled: true },
  { id: "bank_transfer", label: "Bank transfer", hint: "Transfer details are shown after the order is placed.", enabled: true },
  { id: "online", label: "Card / wallet (online)", hint: "Requires a payment gateway — not configured.", enabled: isBackendLive },
];

export function CheckoutForm({ products }: { products: Product[] }) {
  const { lines, discountCode, hydrated } = useCart();
  const [state, action, pending] = useActionState<ActionState, FormData>(checkoutAction, {});
  const fe = state.fieldErrors ?? {};

  if (!hydrated) return <div className="skeleton mt-8 h-64 rounded-2xl" aria-busy="true" />;
  if (lines.length === 0)
    return (
      <div className="mt-8 rounded-2xl bg-sage-100 p-10 text-center">
        <p className="font-display text-xl text-forest-950">Nothing to check out</p>
        <p className="mb-5 mt-1 text-sm text-forest-700">Your cart is empty.</p>
        <ButtonLink href="/shop">Browse products</ButtonLink>
      </div>
    );

  const priced = priceCart(lines, products, discountCode);
  return (
    <form action={action} className="mt-8 grid gap-8 lg:grid-cols-[1fr_340px]" noValidate>
      <input type="hidden" name="cart" value={JSON.stringify(lines)} />
      <input type="hidden" name="discountCode" value={discountCode} />
      <div className="space-y-8">
        {!isBackendLive && (
          <Notice tone="demo" title="Demo checkout">
            You can fill in and validate this form, but <strong>no order will be created and no payment taken</strong> until the backend is connected.
          </Notice>
        )}
        {state.message && (
          <Notice tone={state.code === "BACKEND_NOT_CONFIGURED" ? "demo" : "error"} title={state.code === "BACKEND_NOT_CONFIGURED" ? "Form is valid — order not placed" : "Could not place order"}>
            {state.message}
            {state.serverTotal !== undefined && <> Server-calculated total: <strong>{formatPKR(state.serverTotal)}</strong>.</>}
          </Notice>
        )}
        <fieldset className="space-y-4">
          <legend className="font-display text-2xl text-forest-950">Delivery details</legend>
          <Field label="Full name" name="fullName" autoComplete="name" error={fe.fullName?.[0]} />
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Email" name="email" type="email" autoComplete="email" error={fe.email?.[0]} />
            <Field label="Mobile number" name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="03XX XXXXXXX" error={fe.phone?.[0]} />
          </div>
          <Field label="Delivery address" name="address" autoComplete="street-address" error={fe.address?.[0]} />
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="City" name="city" autoComplete="address-level2" error={fe.city?.[0]} />
            <Field label="Postal code (optional)" name="postalCode" required={false} autoComplete="postal-code" />
          </div>
        </fieldset>
        <fieldset>
          <legend className="font-display text-2xl text-forest-950">Payment method</legend>
          <div className="mt-3 space-y-3">
            {methods.map((m) => (
              <label key={m.id} className={`flex gap-3 rounded-xl border border-beige-400 bg-white p-4 ${m.enabled ? "cursor-pointer" : "opacity-50"}`}>
                <input type="radio" name="paymentMethod" value={m.id} disabled={!m.enabled} defaultChecked={m.id === "cod"} className="mt-1" />
                <span><span className="block font-medium text-forest-950">{m.label}</span><span className="text-sm text-forest-700">{m.hint}</span></span>
              </label>
            ))}
          </div>
          {fe.paymentMethod?.[0] && <p className="mt-1 text-sm text-red-700">{fe.paymentMethod[0]}</p>}
        </fieldset>
      </div>
      <aside className="space-y-4">
        <OrderSummary priced={priced} />
        <button type="submit" disabled={pending || priced.hasIssues} className={`${buttonClass()} w-full`}>{pending ? "Checking…" : isBackendLive ? "Place order" : "Validate order (demo)"}</button>
      </aside>
    </form>
  );
}
