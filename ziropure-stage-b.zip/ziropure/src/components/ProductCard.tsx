"use client";
import Link from "next/link";
import { motion, useReducedMotion } from "motion/react";
import { formatPKR } from "@/lib/format";
import type { Product } from "@/lib/types";
import { AddToCartButton } from "./AddToCartButton";
import { ProductImage } from "./ProductImage";

export function ProductCard({ product, brandName }: { product: Product; brandName: string }) {
  const reduce = useReducedMotion();
  return (
    <motion.article
      whileHover={reduce ? undefined : { y: -6 }} transition={{ type: "spring", stiffness: 300, damping: 22 }}
      className="flex flex-col rounded-3xl border border-beige-200 bg-white p-3 shadow-sm"
    >
      <Link href={`/shop/${product.slug}`} className="block">
        <ProductImage tint={product.tint} name={product.name} />
        <p className="mt-3 text-xs uppercase tracking-wider text-sage-500">{brandName}</p>
        <h3 className="mt-1 font-display text-lg leading-snug text-forest-950">{product.name}</h3>
      </Link>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="font-semibold text-forest-900">{formatPKR(product.price)}</span>
        {product.compareAtPrice && <span className="text-sm text-sage-500 line-through">{formatPKR(product.compareAtPrice)}</span>}
      </div>
      {product.stock > 0 && product.stock <= 10 && <p className="mt-1 text-xs text-amber-700">Only {product.stock} left</p>}
      <div className="mt-3 pt-1"><AddToCartButton productId={product.id} stock={product.stock} full /></div>
    </motion.article>
  );
}
