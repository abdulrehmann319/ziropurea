"use client";
import { motion, useReducedMotion } from "motion/react";

const ys = [320, 250, 180, 110];

/** Botanical sprig that draws itself on load (static when reduced motion is requested). */
export function Sprig({ className = "" }: { className?: string }) {
  const reduce = useReducedMotion();
  const draw = (delay: number) => ({
    initial: reduce ? { pathLength: 1, opacity: 1 } : { pathLength: 0, opacity: 0 },
    animate: { pathLength: 1, opacity: 1 },
    transition: { duration: 1.4, delay, ease: "easeInOut" as const },
  });
  return (
    <svg viewBox="0 0 200 400" aria-hidden className={className} fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
      <motion.path d="M100 390 C100 300 106 200 100 50" {...draw(0)} />
      {ys.map((y, i) => (
        <g key={y}>
          <motion.path d={`M100 ${y} C70 ${y - 10} 48 ${y - 40} 54 ${y - 62} C86 ${y - 56} 106 ${y - 30} 100 ${y}Z`} {...draw(0.4 + i * 0.25)} />
          <motion.path d={`M100 ${y - 24} C130 ${y - 34} 152 ${y - 64} 146 ${y - 86} C114 ${y - 80} 94 ${y - 54} 100 ${y - 24}Z`} {...draw(0.55 + i * 0.25)} />
        </g>
      ))}
    </svg>
  );
}
