"use client";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { useCart } from "./CartProvider";

const links = [
  { href: "/shop", label: "Shop" },
  { href: "/brands", label: "Brands" },
  { href: "/skincare-info", label: "Skincare Guide" },
  { href: "/contact", label: "Contact" },
];

export function Header() {
  const [open, setOpen] = useState(false);
  const { count } = useCart();
  const pathname = usePathname();
  const reduce = useReducedMotion();
  const current = (href: string) => (pathname === href || pathname.startsWith(`${href}/`) ? "page" : undefined);

  useEffect(() => { setOpen(false); }, [pathname]);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header className="sticky top-0 z-50 border-b border-beige-200 bg-cream-50/90 backdrop-blur">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:bg-white focus:p-2">Skip to content</a>
      <nav aria-label="Primary" className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <Image src="/logo.jpg" alt="" width={36} height={36} className="rounded-md" priority />
          <span className="font-display text-xl tracking-wide text-forest-900">Ziropure</span>
        </Link>
        <ul className="hidden gap-8 md:flex">
          {links.map((l) => (
            <li key={l.href}>
              <Link href={l.href} aria-current={current(l.href)} className="text-sm text-forest-900 transition hover:text-forest-600 aria-[current=page]:font-semibold aria-[current=page]:underline aria-[current=page]:underline-offset-8">{l.label}</Link>
            </li>
          ))}
        </ul>
        <div className="flex items-center gap-4">
          <Link href="/cart" className="text-sm text-forest-900" aria-label={`Cart, ${count} items`}>
            Cart{count > 0 && <span className="ml-1 rounded-full bg-forest-900 px-2 py-0.5 text-xs text-cream-50">{count}</span>}
          </Link>
          <Link href="/login" className="hidden text-sm text-forest-900 md:inline">Sign in</Link>
          <button className="md:hidden" aria-expanded={open} aria-controls="mobile-menu" onClick={() => setOpen(!open)}>
            <span className="sr-only">{open ? "Close menu" : "Open menu"}</span>
            <svg width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" fill="none" aria-hidden><path d={open ? "M6 6l12 12M18 6L6 18" : "M4 7h16M4 12h16M4 17h16"} /></svg>
          </button>
        </div>
      </nav>
      <AnimatePresence>
        {open && (
          <motion.ul
            id="mobile-menu" className="overflow-hidden border-t border-beige-200 bg-cream-50 px-4 md:hidden"
            initial={reduce ? false : { height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
            exit={reduce ? { opacity: 0 } : { height: 0, opacity: 0 }} transition={{ duration: 0.25 }}
          >
            {[...links, { href: "/account", label: "My account" }, { href: "/login", label: "Sign in" }].map((l) => (
              <li key={l.href}><Link href={l.href} aria-current={current(l.href)} className="block py-3 text-forest-900">{l.label}</Link></li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>
    </header>
  );
}
