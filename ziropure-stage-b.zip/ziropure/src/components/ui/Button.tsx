import Link from "next/link";

const base = "inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-50";
const variants = {
  primary: "bg-forest-900 text-cream-50 hover:bg-forest-700",
  outline: "border border-forest-900 text-forest-900 hover:bg-sage-100",
} as const;

export function ButtonLink({ href, variant = "primary", children }: { href: string; variant?: keyof typeof variants; children: React.ReactNode }) {
  return <Link href={href} className={`${base} ${variants[variant]}`}>{children}</Link>;
}
export const buttonClass = (variant: keyof typeof variants = "primary") => `${base} ${variants[variant]}`;
