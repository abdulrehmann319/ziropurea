type Props = {
  label: string; name: string; type?: string; error?: string; autoComplete?: string;
  required?: boolean; placeholder?: string; defaultValue?: string; inputMode?: "text" | "tel" | "email" | "numeric";
};

export function Field({ label, name, type = "text", error, autoComplete, required = true, placeholder, defaultValue, inputMode }: Props) {
  const id = `f-${name}`;
  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-forest-900">{label}</label>
      <input
        id={id} name={name} type={type} autoComplete={autoComplete} required={required} placeholder={placeholder}
        defaultValue={defaultValue} inputMode={inputMode} aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-err` : undefined}
        className="mt-1 w-full rounded-lg border border-beige-400 bg-white px-3 py-2.5 text-ink placeholder:text-sage-500 focus:border-forest-600"
      />
      {error && <p id={`${id}-err`} className="mt-1 text-sm text-red-700">{error}</p>}
    </div>
  );
}
