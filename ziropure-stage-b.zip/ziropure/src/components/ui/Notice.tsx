const tones = {
  demo: "border-beige-400 bg-beige-200/60 text-forest-950",
  error: "border-red-300 bg-red-50 text-red-900",
  success: "border-sage-500 bg-sage-100 text-forest-950",
  info: "border-sage-300 bg-white text-forest-900",
} as const;

export function Notice({ tone = "info", title, children }: { tone?: keyof typeof tones; title?: string; children: React.ReactNode }) {
  return (
    <div role={tone === "error" ? "alert" : "status"} className={`rounded-xl border px-4 py-3 text-sm ${tones[tone]}`}>
      {title && <p className="font-semibold">{title}</p>}
      <div>{children}</div>
    </div>
  );
}
