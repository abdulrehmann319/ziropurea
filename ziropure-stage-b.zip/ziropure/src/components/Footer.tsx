import Link from "next/link";
import { isBackendLive } from "@/config/env";

const cols = [
  { title: "Help", items: [["Shipping", "/shipping"], ["Returns", "/returns"], ["Contact", "/contact"]] },
  { title: "Legal", items: [["Privacy", "/privacy"], ["Terms", "/terms"]] },
  { title: "Learn", items: [["Skincare information", "/skincare-info"]] },
];

export function Footer() {
  return (
    <footer className="mt-24 bg-forest-950 text-cream-100">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 md:grid-cols-4">
        <div>
          <p className="font-display text-2xl">Ziropure</p>
          <p className="mt-3 text-sm text-sage-300">Herbal skincare, delivered across Pakistan.</p>
          {!isBackendLive && <Link href="/admin" className="mt-4 inline-block text-xs text-sage-300 underline">Admin dashboard (demo)</Link>}
        </div>
        {cols.map((c) => (
          <div key={c.title}>
            <h2 className="text-sm font-semibold uppercase tracking-wider text-sage-300">{c.title}</h2>
            <ul className="mt-3 space-y-2 text-sm">
              {c.items.map(([label, href]) => <li key={href}><Link href={href} className="hover:text-white">{label}</Link></li>)}
            </ul>
          </div>
        ))}
      </div>
      <p className="border-t border-forest-700 py-5 text-center text-xs text-sage-300">© {new Date().getFullYear()} Ziropure. All rights reserved.</p>
    </footer>
  );
}
