/** "demo" = sample data, no backend. "supabase" = real backend (after you implement src/server/supabase/*). */
export type BackendMode = "demo" | "supabase";
export const BACKEND_MODE: BackendMode = process.env.NEXT_PUBLIC_BACKEND_MODE === "supabase" ? "supabase" : "demo";
export const isBackendLive = BACKEND_MODE === "supabase";
