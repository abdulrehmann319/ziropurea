export const CURRENCY = "PKR";
export const DELIVERY_FEE = 250;
export const FREE_DELIVERY_OVER = 5000;
export const MAX_QTY_PER_LINE = 10;
/** SAMPLE discount codes for the demo only. In production, discounts live in the database and are validated server-side. */
export const DISCOUNT_CODES: Record<string, { percent: number; label: string }> = {
  WELCOME10: { percent: 10, label: "Sample: 10% off" },
};
