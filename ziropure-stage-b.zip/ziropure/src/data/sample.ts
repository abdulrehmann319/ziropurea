/** ⚠️ SAMPLE DATA — fictional products, brands and orders for the demo preview only. Replace via your database. */
import type { AdminOrder, Brand, Category, Product } from "@/lib/types";

export const SAMPLE_BRANDS: Brand[] = [
  { id: "b1", slug: "ziropure", name: "Ziropure", isOwn: true },
  { id: "b2", slug: "demo-botanica", name: "Demo Botanica", isOwn: false },
  { id: "b3", slug: "demo-dermaline", name: "Demo Dermaline", isOwn: false },
];
export const SAMPLE_CATEGORIES: Category[] = [
  { id: "c1", slug: "cleansers", name: "Cleansers" },
  { id: "c2", slug: "serums", name: "Serums" },
  { id: "c3", slug: "moisturizers", name: "Moisturizers" },
  { id: "c4", slug: "masks", name: "Masks & Toners" },
  { id: "c5", slug: "sun-care", name: "Sun Care" },
];

const p = (
  id: string, slug: string, name: string, brandId: string, categoryId: string, price: number, stock: number, tint: string,
  shortDescription: string, ingredients: string[], tags: string[], compareAtPrice?: number,
): Product => ({
  id, slug, name, brandId, categoryId, price, stock, tint, shortDescription, ingredients, tags, compareAtPrice,
  description: `${shortDescription} This is sample copy written for the demo store; replace it with your real product description.`,
});

export const SAMPLE_PRODUCTS: Product[] = [
  p("p1", "neem-tulsi-face-wash", "Neem & Tulsi Face Wash", "b1", "c1", 850, 42, "#5f8a68", "Gentle daily gel cleanser with neem and holy basil.", ["Neem extract", "Tulsi extract", "Glycerin"], ["herbal", "oily skin"]),
  p("p2", "aloe-hydrating-gel", "Aloe Vera Hydrating Gel", "b1", "c3", 990, 30, "#8fb996", "Lightweight, non-sticky gel moisture for all skin types.", ["Aloe vera", "Cucumber extract", "Hyaluronic acid"], ["herbal", "hydration"], 1190),
  p("p3", "rose-water-toner", "Rose Water Toner", "b1", "c4", 750, 55, "#d9a5a0", "Refreshing alcohol-free toner with steam-distilled rose water.", ["Rose water", "Witch hazel", "Glycerin"], ["herbal", "toner"]),
  p("p4", "saffron-night-serum", "Saffron Night Serum", "b1", "c2", 2650, 12, "#d6a24a", "Overnight glow serum with saffron and niacinamide.", ["Saffron extract", "Niacinamide", "Squalane"], ["herbal", "glow"], 2990),
  p("p5", "sandalwood-clay-mask", "Sandalwood Clay Mask", "b1", "c4", 1150, 8, "#b79b72", "Weekly purifying clay mask with sandalwood and multani mitti.", ["Multani mitti", "Sandalwood", "Rose petal"], ["herbal", "mask"]),
  p("p6", "vitamin-c-serum", "Vitamin C Brightening Serum", "b3", "c2", 3200, 20, "#e8a33d", "Stable vitamin C serum for a brighter-looking complexion.", ["Ascorbic acid", "Ferulic acid", "Vitamin E"], ["brightening"]),
  p("p7", "ceramide-moisturizer", "Ceramide Barrier Moisturizer", "b3", "c3", 2450, 0, "#9bb7c9", "Rich cream that supports the skin barrier.", ["Ceramides", "Panthenol", "Shea butter"], ["barrier", "dry skin"]),
  p("p8", "spf-50-sunscreen", "SPF 50 Daily Sunscreen", "b2", "c5", 1800, 64, "#f0c75e", "Broad-spectrum, no-white-cast daily sunscreen.", ["Zinc oxide", "Aloe vera", "Vitamin E"], ["spf", "daily"]),
  p("p9", "turmeric-clarifying-cleanser", "Turmeric Clarifying Cleanser", "b2", "c1", 1250, 25, "#d9a52f", "Foaming cleanser with turmeric and green tea.", ["Turmeric", "Green tea", "Chamomile"], ["herbal", "clarifying"]),
];

export const SAMPLE_ORDERS: AdminOrder[] = [
  { id: "SAMPLE-1001", customerName: "Ayesha Khan", city: "Lahore", total: 2090, status: "pending", paymentMethod: "cod", paymentStatus: "unpaid", createdAt: "2026-10-19T10:20:00Z" },
  { id: "SAMPLE-1000", customerName: "Bilal Ahmed", city: "Karachi", total: 3450, status: "confirmed", paymentMethod: "bank_transfer", paymentStatus: "paid", createdAt: "2026-10-18T15:05:00Z" },
  { id: "SAMPLE-0999", customerName: "Sana Malik", city: "Islamabad", total: 5300, status: "shipped", paymentMethod: "online", paymentStatus: "paid", createdAt: "2026-10-17T09:40:00Z" },
  { id: "SAMPLE-0998", customerName: "Hamza Raza", city: "Faisalabad", total: 1100, status: "delivered", paymentMethod: "cod", paymentStatus: "paid", createdAt: "2026-10-15T13:10:00Z" },
  { id: "SAMPLE-0997", customerName: "Mariam Noor", city: "Multan", total: 1850, status: "cancelled", paymentMethod: "cod", paymentStatus: "unpaid", createdAt: "2026-10-14T18:30:00Z" },
];
