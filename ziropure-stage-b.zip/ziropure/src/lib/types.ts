export type Brand = { id: string; slug: string; name: string; isOwn: boolean };
export type Category = { id: string; slug: string; name: string };
export type Product = {
  id: string; slug: string; name: string; brandId: string; categoryId: string;
  shortDescription: string; description: string; ingredients: string[];
  price: number; compareAtPrice?: number; stock: number; tint: string; tags: string[];
};
export type OrderStatus = "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";
export type PaymentStatus = "unpaid" | "paid" | "failed" | "refunded";
export type PaymentMethod = "cod" | "bank_transfer" | "online";
export type AdminOrder = {
  id: string; customerName: string; city: string; total: number;
  status: OrderStatus; paymentMethod: PaymentMethod; paymentStatus: PaymentStatus; createdAt: string;
};
