export type ActionState = {
  ok?: boolean;
  message?: string;
  code?: string;
  fieldErrors?: Record<string, string[] | undefined>;
  serverTotal?: number;
};
