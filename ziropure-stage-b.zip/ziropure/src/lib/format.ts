const pkr = new Intl.NumberFormat("en-PK", { style: "currency", currency: "PKR", maximumFractionDigits: 0 });
/** Prices are stored as integer PKR (no decimals) to avoid float errors. */
export const formatPKR = (amount: number) => pkr.format(amount);
