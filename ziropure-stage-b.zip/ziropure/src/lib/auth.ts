import "server-only";
import { redirect } from "next/navigation";
import { auth } from "@/server";

export async function requireUser() {
  const user = await auth.getUser();
  if (!user) redirect("/login");
  return user;
}

/** In demo mode the admin UI is previewable (read-only sample data). In live mode it is strictly admin-only. */
export async function requireAdmin() {
  const { isBackendLive } = await import("@/config/env");
  if (!isBackendLive) return null;
  const user = await requireUser();
  if (!(await auth.isAdmin())) redirect("/");
  return user;
}
