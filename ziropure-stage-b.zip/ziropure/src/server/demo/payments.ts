import { notConfigured, type PaymentGateway } from "../contracts";

export const demoPayments: PaymentGateway = {
  async initiate() { return notConfigured("Online payments"); },
  async handleWebhook() { return notConfigured("Payment webhooks"); },
};
