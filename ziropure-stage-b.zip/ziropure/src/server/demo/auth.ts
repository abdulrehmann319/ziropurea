import { notConfigured, type AuthService } from "../contracts";

/** Demo auth: nothing is faked. Every action reports that the backend is not connected. */
export const demoAuth: AuthService = {
  async signInWithPassword() { return notConfigured("Sign-in"); },
  async signUp() { return notConfigured("Registration"); },
  async signInWithGoogle() { return notConfigured("Google sign-in"); },
  async requestPasswordReset() { return notConfigured("Password reset"); },
  async signOut() {},
  async getUser() { return null; },
  async isAdmin() { return false; },
};
