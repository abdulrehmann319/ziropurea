import { SAMPLE_BRANDS, SAMPLE_CATEGORIES, SAMPLE_PRODUCTS } from "@/data/sample";
import type { CatalogRepository } from "../contracts";

export const demoCatalog: CatalogRepository = {
  async listProducts(f = {}) {
    const q = f.q?.trim().toLowerCase();
    const cat = SAMPLE_CATEGORIES.find((c) => c.slug === f.category);
    const brand = SAMPLE_BRANDS.find((b) => b.slug === f.brand);
    let list = SAMPLE_PRODUCTS.filter(
      (p) =>
        (!cat || p.categoryId === cat.id) &&
        (!brand || p.brandId === brand.id) &&
        (!q || [p.name, p.shortDescription, ...p.tags].join(" ").toLowerCase().includes(q)),
    );
    if (f.sort === "price-asc") list = [...list].sort((a, b) => a.price - b.price);
    if (f.sort === "price-desc") list = [...list].sort((a, b) => b.price - a.price);
    return list;
  },
  async getBySlug(slug) { return SAMPLE_PRODUCTS.find((p) => p.slug === slug) ?? null; },
  async getByIds(ids) { return SAMPLE_PRODUCTS.filter((p) => ids.includes(p.id)); },
  async listBrands() { return SAMPLE_BRANDS; },
  async listCategories() { return SAMPLE_CATEGORIES; },
};
