import { SAMPLE_ORDERS } from "@/data/sample";
import { notConfigured, type OrderService } from "../contracts";

export const demoOrders: OrderService = {
  async create() { return notConfigured("Order placement"); },
  async listAll() { return SAMPLE_ORDERS; },
  async listMine() { return SAMPLE_ORDERS.slice(0, 2); }, // SAMPLE rows for the account preview
};
