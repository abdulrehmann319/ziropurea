import type { OrderService } from "../contracts";

/**
 * TODO: implement create() as ONE transactional database function (RPC) that re-reads prices/stock,
 * decrements inventory, inserts order + order_items price snapshots + status history, and is idempotent
 * (accept a client-generated idempotency key). Never trust totals from the browser.
 */
export const supabaseOrders: OrderService = {
  async create() { throw new Error("supabaseOrders.create is not implemented yet."); },
  async listAll() { throw new Error("supabaseOrders.listAll is not implemented yet."); },
  async listMine() { throw new Error("supabaseOrders.listMine is not implemented yet."); },
};
