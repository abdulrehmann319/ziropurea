import { createClient } from "@/lib/supabase/server";
import type { AuthService } from "../contracts";

const site = () => process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

/** Real implementation against Supabase Auth (untested until you connect a project). */
export const supabaseAuth: AuthService = {
  async signInWithPassword({ email, password }) {
    const sb = await createClient();
    const { error } = await sb.auth.signInWithPassword({ email, password });
    return error ? { ok: false, code: "AUTH_ERROR", message: error.message } : { ok: true, data: null };
  },
  async signUp({ email, password, fullName }) {
    const sb = await createClient();
    const { error } = await sb.auth.signUp({
      email,
      password,
      options: { data: { full_name: fullName }, emailRedirectTo: `${site()}/auth/callback` },
    });
    return error ? { ok: false, code: "AUTH_ERROR", message: error.message } : { ok: true, data: null };
  },
  async signInWithGoogle() {
    const sb = await createClient();
    const { data, error } = await sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo: `${site()}/auth/callback` } });
    if (error || !data.url) return { ok: false, code: "AUTH_ERROR", message: error?.message ?? "No redirect URL returned" };
    return { ok: true, data: { url: data.url } };
  },
  async requestPasswordReset(email) {
    const sb = await createClient();
    // TODO (Stage C): build /account/update-password so the user can set a new password after the callback.
    const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${site()}/auth/callback?next=/account` });
    return error ? { ok: false, code: "AUTH_ERROR", message: error.message } : { ok: true, data: null };
  },
  async signOut() {
    const sb = await createClient();
    await sb.auth.signOut();
  },
  async getUser() {
    const sb = await createClient();
    const { data: { user } } = await sb.auth.getUser();
    return user ? { id: user.id, email: user.email ?? "" } : null;
  },
  async isAdmin() {
    const sb = await createClient();
    const { data: { user } } = await sb.auth.getUser();
    if (!user) return false;
    const { data } = await sb.from("profiles").select("role").eq("id", user.id).single();
    return data?.role === "admin";
  },
};
