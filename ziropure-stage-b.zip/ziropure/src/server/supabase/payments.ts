import type { PaymentGateway } from "../contracts";

/** TODO: implement for your chosen Pakistani gateway. Verify the provider signature server-side and upsert payments by (provider, provider_ref). */
export const supabasePayments: PaymentGateway = {
  async initiate() { throw new Error("supabasePayments.initiate is not implemented yet."); },
  async handleWebhook() { throw new Error("supabasePayments.handleWebhook is not implemented yet."); },
};
