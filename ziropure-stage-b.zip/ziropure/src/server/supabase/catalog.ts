import type { CatalogRepository } from "../contracts";

const todo = (m: string): never => {
  throw new Error(`supabaseCatalog.${m} is not implemented yet. Implement it against your Supabase schema (products, brands, categories, product_images).`);
};

/** TODO: implement with createClient() from "@/lib/supabase/server". Map DB rows to the types in src/lib/types.ts. */
export const supabaseCatalog: CatalogRepository = {
  async listProducts() { return todo("listProducts"); },
  async getBySlug() { return todo("getBySlug"); },
  async getByIds() { return todo("getByIds"); },
  async listBrands() { return todo("listBrands"); },
  async listCategories() { return todo("listCategories"); },
};
