import { isBackendLive } from "@/config/env";
import type { AuthService, CatalogRepository, OrderService, PaymentGateway } from "./contracts";
import { demoAuth } from "./demo/auth";
import { demoCatalog } from "./demo/catalog";
import { demoOrders } from "./demo/orders";
import { demoPayments } from "./demo/payments";
import { supabaseAuth } from "./supabase/auth";
import { supabaseCatalog } from "./supabase/catalog";
import { supabaseOrders } from "./supabase/orders";
import { supabasePayments } from "./supabase/payments";

/** The ONLY place that decides demo vs Supabase. Pages and actions import from here. */
export const catalog: CatalogRepository = isBackendLive ? supabaseCatalog : demoCatalog;
export const auth: AuthService = isBackendLive ? supabaseAuth : demoAuth;
export const orders: OrderService = isBackendLive ? supabaseOrders : demoOrders;
export const payments: PaymentGateway = isBackendLive ? supabasePayments : demoPayments;
