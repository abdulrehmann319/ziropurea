import type { AdminOrder, Brand, Category, Product } from "@/lib/types";
import type { PricedCart } from "@/domain/pricing";
import type { CheckoutInput } from "@/domain/validation";

export type Result<T> = { ok: true; data: T } | { ok: false; code: string; message: string };
export const NOT_CONFIGURED = "BACKEND_NOT_CONFIGURED";
export const notConfigured = (feature: string): { ok: false; code: string; message: string } => ({
  ok: false,
  code: NOT_CONFIGURED,
  message: `${feature} is not connected yet. Configure Supabase and set NEXT_PUBLIC_BACKEND_MODE=supabase (see README).`,
});

export interface ProductFilters { q?: string; category?: string; brand?: string; sort?: "featured" | "price-asc" | "price-desc" }
export interface CatalogRepository {
  listProducts(filters?: ProductFilters): Promise<Product[]>;
  getBySlug(slug: string): Promise<Product | null>;
  getByIds(ids: string[]): Promise<Product[]>;
  listBrands(): Promise<Brand[]>;
  listCategories(): Promise<Category[]>;
}

export interface AuthUser { id: string; email: string }
export interface AuthService {
  signInWithPassword(i: { email: string; password: string }): Promise<Result<null>>;
  signUp(i: { email: string; password: string; fullName: string }): Promise<Result<null>>;
  /** Returns the provider URL to redirect to. */
  signInWithGoogle(): Promise<Result<{ url: string }>>;
  requestPasswordReset(email: string): Promise<Result<null>>;
  signOut(): Promise<void>;
  getUser(): Promise<AuthUser | null>;
  isAdmin(): Promise<boolean>;
}

export interface NewOrder { customer: CheckoutInput; priced: PricedCart }
export interface OrderService {
  /** Receives a cart priced on the server from DB products. Never trust browser totals. */
  create(order: NewOrder): Promise<Result<{ orderId: string }>>;
  listAll(): Promise<AdminOrder[]>;
  /** Orders belonging to one customer (enforced by RLS in the Supabase implementation). */
  listMine(userId: string): Promise<AdminOrder[]>;
}

export interface PaymentGateway {
  initiate(i: { orderId: string; amount: number }): Promise<Result<{ redirectUrl: string }>>;
  /** Verify provider signature + idempotency inside the webhook route. */
  handleWebhook(req: Request): Promise<Result<null>>;
}
