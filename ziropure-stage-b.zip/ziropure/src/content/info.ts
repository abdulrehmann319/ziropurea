export type InfoContent = { title: string; intro: string; sections: { heading: string; body: string }[] };
const TEMPLATE = "Template text for the demo — replace with your real policy and have it reviewed before launch.";

export const INFO: Record<string, InfoContent> = {
  shipping: { title: "Shipping", intro: TEMPLATE, sections: [
    { heading: "Delivery areas", body: "We deliver across Pakistan through our courier partners." },
    { heading: "Delivery fees", body: "A flat fee of PKR 250 applies; orders of PKR 5,000 or more ship free." },
    { heading: "Delivery time", body: "Estimated 3–5 working days for major cities and 5–8 days elsewhere." } ] },
  returns: { title: "Returns & refunds", intro: TEMPLATE, sections: [
    { heading: "Eligibility", body: "Unopened items can be returned within 7 days of delivery." },
    { heading: "Damaged or wrong items", body: "Contact us within 48 hours with photos and we will replace or refund." },
    { heading: "Refunds", body: "Approved refunds are issued to the original payment method or by bank transfer." } ] },
  privacy: { title: "Privacy policy", intro: TEMPLATE, sections: [
    { heading: "What we collect", body: "Only the details needed to fulfil your order: name, contact details, delivery address and order history." },
    { heading: "How we use it", body: "To process orders, provide support and send order updates. We do not sell personal data." },
    { heading: "Your choices", body: "You can request access to, or deletion of, your data by contacting us." } ] },
  terms: { title: "Terms & conditions", intro: TEMPLATE, sections: [
    { heading: "Orders", body: "An order is confirmed once we verify stock and, where applicable, payment." },
    { heading: "Pricing", body: "All prices are in PKR. We may correct pricing errors before confirming an order." },
    { heading: "Liability", body: "Skincare results vary between individuals. Always patch-test and follow product directions." } ] },
  contact: { title: "Contact us", intro: TEMPLATE, sections: [
    { heading: "Email", body: "hello@your-domain.example (placeholder)" },
    { heading: "Phone / WhatsApp", body: "+92 3XX XXXXXXX (placeholder)" },
    { heading: "Hours", body: "Monday–Saturday, 10am–6pm PKT (placeholder)" } ] },
  "skincare-info": { title: "Skincare guide", intro: "General educational information, not medical advice.", sections: [
    { heading: "Build a simple routine", body: "Cleanse, treat, moisturise, and use sunscreen every morning. Introduce one new product at a time." },
    { heading: "Patch-test first", body: "Apply a small amount on the inner forearm for 24 hours before using a new product on your face." },
    { heading: "Know your skin type", body: "Oily, dry, combination and sensitive skin each benefit from different textures and ingredients." },
    { heading: "See a professional", body: "For persistent acne, rashes or irritation, consult a qualified dermatologist." } ] },
};
